// REDUX ACTION TYPES
export const TICK = 'TICK'
export const INCREMENT = 'INCREMENT'
export const DECREMENT = 'DECREMENT'
export const RESET = 'RESET'
